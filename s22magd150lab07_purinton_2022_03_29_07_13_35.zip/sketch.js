let raindrops=[];
let ground = 100;
let height1=400
let width1=400;

function setup() {
  createCanvas(height1, width1);
  for(let i=0; i<(width1/10);i++){//this is how the number of raindrops is 
  raindrops[i] = new Rain(i*10);  //is decided and their locations created
  }
}
 
function draw() {
  background('#00bfff');
  for(let i=0; i<width1/10;i++){
    raindrops[i].show();
    raindrops[i].fall();
    rectMode(CENTER);
    fill('#2c6d08');
    rect(width/2,height-ground/2,width,ground);
    
  }
}

class Rain {
  constructor(xPos){//This is how each raindrop is first created giving a random y location and a set x location that will change in the sketch
    this.x=xPos;
    this.y=random(0,height-ground);
  }
   fall(){//This controls how the drops fall moving a random amount down and changing a little from left to right
     this.y=this.y+random(0,5);
     if(this.y>=height-ground){
       this.y=0;//if the drops get to the ground they reset up to the top
     }
     this.x=this.x+random(-2,2);
   }
  show(){//this shows the drops
    fill(0,0,190);
    ellipse(this.x, this.y, 2,4);
  }
  
}