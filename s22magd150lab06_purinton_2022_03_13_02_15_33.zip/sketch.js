let rotation = 110;
let p1 = true;
let x=1
function setup() {
  createCanvas(800, 800);
  angleMode(DEGREES);
  rectMode(CENTER);
  frameRate(60);
}

function draw() {
  background(8,70,158);
  fill(216,158,109)
  rect(400, 600, 800, 400)
  translate(400, 300);
  rotate(rotation);
  line(0,0,100,200)
  translate(100, 200);
  rotate(-rotation);
  scale(x);
  if(rotation<200){
    x=x+0.01;
  }else{
    x=x-0.01;
  }
  if (p1===true){
  Mario();
  }else{
    Luigi();
  }
  rotation++;
  CheckRotation();
}

function CheckRotation(){
  if(rotation == 290){
    rotation = 110;
    if(p1===true){
      p1=false;
    }else{
      p1=true
    }
  }
}

function Mario(){
  /*Mario's hat*/
  noStroke();
  fill(254,0,2)
  rect(-10, 0, 60, 20);
  rect(-0, 5, 100, 10);
  
  /*Mario's Face*/
  fill(255,217,135)
  rect(-5,35,70,50);
  rect(-45,30,10,20);
  rect(35,30,10,20);
  rect(45,35,10,10);
  
  /*Mario's Hair*/
  fill(106,4,0);
  rect(-35,15,30,10);
  rect(-35,25,10,30);
  rect(-26,35,10,10);
  rect(-55,35,10,30);
  rect(-46,45,10,10);
  
  /*Mario's Mustache*/
  rect(15,20,10,20);
  rect(25,35,10,10);
  rect(25,45,30,10);
  
  /*Mario's Body*/
  fill(0,1,252);
  rect(-10,85,80,50);
  rect(39,95,20,30);
  rect(-20,114,60,10);
  fill(254,0,2);
  rect(-50,70,40,20);
  rect(-40,80,40,20);
  rect(-5,65,30,10);
  rect(5,74,30,10);
  rect(30,65,20,10);
  rect(40,55,20,10);
  rect(45,45,10,10);
  rect(55,35,10,10);
  rect(50,20,20,20);
  rect(35,15,10,10);
  
  /*Mario's Hand*/
  fill(255,217,135);
  rect(50,0,20,20);
  rect(35,-5,10,10);
  
  /*Mario's Feet*/
  fill(106,4,0)
  rect(59,90,20,40);
  rect(65,85,10,50);
  rect(-60,109,20,20);
  rect(-70,119,20,20);
}

function Luigi(){
  /*Luigi's hat*/
  noStroke();
  fill(24,222,44)
  rect(-10, 0, 60, 20);
  rect(-0, 5, 100, 10);
  
  /*Luigi's Face*/
  fill(255,217,135)
  rect(-5,35,70,50);
  rect(-45,30,10,20);
  rect(35,30,10,20);
  rect(45,35,10,10);
  
  /*Luigi's Hair*/
  fill(106,4,0);
  rect(-35,15,30,10);
  rect(-35,25,10,30);
  rect(-26,35,10,10);
  rect(-55,35,10,30);
  rect(-46,45,10,10);
  
  /*Luigi's Mustache*/
  rect(15,20,10,20);
  rect(25,35,10,10);
  rect(25,45,30,10);
  
  /*Luigi's Body*/
  fill(0,1,252);
  rect(-10,85,80,50);
  rect(39,95,20,30);
  rect(-20,114,60,10);
  fill(24,222,44);
  rect(-50,70,40,20);
  rect(-40,80,40,20);
  rect(-5,65,30,10);
  rect(5,74,30,10);
  rect(30,65,20,10);
  rect(40,55,20,10);
  rect(45,45,10,10);
  rect(55,35,10,10);
  rect(50,20,20,20);
  rect(35,15,10,10);
  
  /*Luigi's Hand*/
  fill(255,217,135);
  rect(50,0,20,20);
  rect(35,-5,10,10);
  
  /*Luigi's Feet*/
  fill(106,4,0)
  rect(59,90,20,40);
  rect(65,85,10,50);
  rect(-60,109,20,20);
  rect(-70,119,20,20);
}



