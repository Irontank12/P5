var circle1 = 0;
var circle2 = 400;
var d = 0.0000001
var goUp=true;

function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(0, 0, mouseX%255);
  
  if ( circle1 >= circle2){
    goUp=false;
  }
  if(circle1 == 0){
    goUp=true;
  }
  if(goUp==true){
    circle1++;
    circle2--;
  }else{
    circle1--;
    circle2++;
  }
  fill(51, 153, 255);
  
  var circle2Con = constrain(mouseX, circle2/2, 800-circle2/2);
  var yMap = map(mouseY, 0, height, 100, 700);
  ellipse(circle2Con,yMap, circle2, circle2);
  fill(0, 76, 152);
  ellipse(mouseX,yMap, circle1, circle1);
  var deltaX= mouseX-pmouseX;
  var deltaY= mouseY-pmouseY;
  d = dist(mouseX, mouseY, pmouseX, pmouseY);
  print("Change in X:" + deltaX+" Change in Y:" + deltaY);
  print("Distance:"+ d);
}