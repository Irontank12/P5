let i = 0;
let x=[];
let y=[];
function setup() {
  createCanvas(400, 400);
  frameRate(20);
}

function draw() {
    i++;
    if (i%130==1){
      fill(247, 228, 196);
      ellipse(200, 150, 250, 250);
    } else if (i%130==10){
      fill(178,24,7);
      ellipse(200, 150, 200, 200);
    } else if (i%130==20){
      fill(255,216,103);
      ellipse(200,150,180,180);
    } else if (i%130==30){
      fill(187,17,42);
      ellipse(200,150,20,20);
      ellipse(200,175,20,20);
      ellipse(200,200,20,20);
      ellipse(200,225,20,20);
      ellipse(200,250,20,20);
      ellipse(200,125,20,20);
      ellipse(200,100,20,20);
      ellipse(200,75,20,20);
      ellipse(200,50,20,20);
      
      ellipse(170,150,20,20);
      ellipse(170,175,20,20);
      ellipse(170,200,20,20);
      ellipse(170,225,20,20);
      ellipse(170,125,20,20);
      ellipse(170,100,20,20);
      ellipse(170,75,20,20);
      
      ellipse(230,150,20,20);
      ellipse(230,175,20,20);
      ellipse(230,200,20,20);
      ellipse(230,225,20,20);
      ellipse(230,125,20,20);
      ellipse(230,100,20,20);
      ellipse(230,75,20,20);
      
      ellipse(140,150,20,20);
      ellipse(140,175,20,20);
      ellipse(140,200,20,20);
      ellipse(140,125,20,20);
      ellipse(140,100,20,20);
      
      ellipse(260,150,20,20);
      ellipse(260,175,20,20);
      ellipse(260,200,20,20);
      ellipse(260,125,20,20);
      ellipse(260,100,20,20);
      
      ellipse(110,150,20,20);
      ellipse(110,175,20,20);
      ellipse(110,125,20,20);
      
      ellipse(290,150,20,20);
      ellipse(290,175,20,20);
      ellipse(290,125,20,20);
    } else if (i%130==40){
      line(200, 25, 200, 275);
    } else if (i%130==50){
      line(75, 150, 325, 150);
    }else if (i%130==60){
      line(105, 68, 295, 232);
    }else if (i%130==70){
      line(105, 232, 295, 68);
    }else if (i%130==90){
      fill(255);
      arc(200,150,250,250,0,HALF_PI);
    }else if (i%130==100){
      fill(255);
      arc(200,150,250,250,0,PI);
    }else if (i%130==110){
      fill(255);
      arc(200,150,250,250,0,HALF_PI+PI);
    }else if (i%130==120){
      fill(255);
      arc(200,150,250,250,0,PI+PI);
    }
}
function mousePressed(){
  x.push(mouseX);
  y.push(mouseY);
  fill(247, 228, 196);
  ellipse(mouseX,mouseY,100,100);
  fill(178,24,7);
  ellipse(mouseX,mouseY,90,90);
  fill(255,216,103);
  ellipse(mouseX,mouseY,80,80);
  
  fill(187,17,42);
  ellipse(mouseX,mouseY,10,10);
  ellipse(mouseX+10,mouseY+25,10,10);
  ellipse(mouseX+25,mouseY+10,10,10);
  ellipse(mouseX-10,mouseY-25,10,10);
  ellipse(mouseX-25,mouseY-10,10,10);
  ellipse(mouseX-10,mouseY+25,10,10);
  ellipse(mouseX-25,mouseY+10,10,10);
  ellipse(mouseX+10,mouseY-25,10,10);
  ellipse(mouseX+25,mouseY-10,10,10);
  print(x.length);
}
function keyPressed(){
  for (let c = 0; c<x.length; c++){
    fill(255);
    ellipse(x[c],y[c], 100, 100);
  }
  while (x.length>0){
    x.pop();
    y.pop();
  }
}