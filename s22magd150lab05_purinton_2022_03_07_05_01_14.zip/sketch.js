let y = 220;
let x = 200;
let b1X = 0;
let b1Y = 0;
let b2X = 25;
let b2Y = 360;
let angle = 0;
let on = false;
let rotation = false;

function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES);
}

function draw() {
  background(200);
  rectMode(CENTER);
  ellipseMode(CENTER);
  fill(255,0,0);
  rect(b2X, b2Y, 60, 20);
  fill(0);
  textSize(20);
  text("1/0",b2X-15,b2Y+7);
  dist2 = dist(mouseX, mouseY, 25, 360);
    if(dist2<30){
    fill(150,0,0);
    rect(b2X, b2Y, 60, 20);
  }
  translate(x, y);
  rotate(angle);
  fill(164,116,73);
  rect(-100,20, 20,100);
  rect(100, 20, 20,100);
  rect(0,-80, 300,200, 20);
  
  fill(0);
  rect(0,-95, 250, 150, 20);
  fill(255,0,0);
  ellipse(b1X, b1Y, 20, 20);
  fill(0);
  textSize(20);
  text("Rotate",-30,5);
  dist1 = dist(mouseX, mouseY, 200, 220);
  if(dist1<10){
    fill(150,0,0);
    ellipse(b1X, b1Y, 20, 20);
  }
  if(rotation==true){
    angle++;
  }
  if(on==false){
    fill(0);
  rect(0,-95, 250, 150, 20);
  }else if (on==true){
    fill(191,191,191);
  rect(-108,-95, 36, 150,20, 0, 0, 20);
    fill(191,191,0);
  rect(-72,-95, 36, 150);
    fill(0, 191,191);
  rect(-36,-95, 36, 150);
    fill(0, 191, 0);
  rect(0,-95, 36, 150);
    fill(191, 0, 191);
  rect(36,-95, 36, 150);
    fill(191, 0, 0);
  rect(72,-95, 36, 150);
    fill(0, 0, 191);
  rect(108,-95, 36, 150,0, 20, 20,0);
  }
}
function mousePressed(){
  dist1 = dist(mouseX, mouseY, 200, 220);
  if(dist1<10){
    if(rotation==false){
      rotation=true;
    }else if(rotation==true){
      rotation = false;
    }
  }
  
  dist2 = dist(mouseX, mouseY, 25, 360);
    if(dist2<30){
      if(on==false){
        on=true;
      }else if(on==true){
        on = false;
    }
  }
}